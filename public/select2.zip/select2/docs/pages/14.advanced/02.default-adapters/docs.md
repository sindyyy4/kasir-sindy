---
title: Built-in adapters
taxonomy:
    category: docs
---

This section describes the built-in adapters for Select2, as well as the decorators they use to expose their functionality.
